Create Regions Repository
