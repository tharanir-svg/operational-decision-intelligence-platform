Create Entity Knowledge Repository
